function dy = Ex2402(x,y)
dy = [y(2);-0.05*(200-y(1))];
